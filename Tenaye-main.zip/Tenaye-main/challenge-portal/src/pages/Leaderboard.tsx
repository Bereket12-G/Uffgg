import LeaderboardJoy from '../components/LeaderboardJoy'

export default function LeaderboardPage() {
  return <LeaderboardJoy />
}