import ChallengeList from '../components/ChallengeList'

export default function ChallengesPage() {
  return <ChallengeList />
}