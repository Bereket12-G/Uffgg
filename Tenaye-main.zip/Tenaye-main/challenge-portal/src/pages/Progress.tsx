import ProgressPlayground from '../components/ProgressPlayground'

export default function ProgressPage() {
  return <ProgressPlayground />
}