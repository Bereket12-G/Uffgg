import CommunityBoard from '../components/CommunityBoard'

export default function CommunityPage() {
  return <CommunityBoard />
}